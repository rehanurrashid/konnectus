@stack('before-scripts')
<!-- Core JS files -->
<script src="{{ asset('admin/js/main/jquery.min.js') }}"></script>
<script src="{{ asset('admin/js/main/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('admin/js/plugins/loaders/blockui.min.js') }}"></script>
<script src="{{ asset('admin/js/plugins/notifications/pnotify.min.js') }}"></script>
<script src="{{ asset('admin/js/demo_pages/extra_pnotify.js') }}"></script>
<!-- /core JS files -->

<!-- Theme JS files -->

<!-- /theme JS files -->

<script type="text/javascript" src="https://kit.fontawesome.com/f4ababfdfc.js"></script>
@stack('after-scripts')
