@extends('layouts.custom')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Congratulations</div>

                <div class="card-body">
                    <h5>You password is successfully changed!</h5>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
